import React from 'react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  PieChart,
  Pie,
  Cell,
  LineChart,
  Line,
  ResponsiveContainer
} from 'recharts';

const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042'];

export default function Analytics({ data }) {
  const {
    serviceData,
    paymentData,
    revenueData,
    pendingPayments,
    topServices,
    expenditureVsRevenue
  } = data;

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
      {/* Services Chart */}
      <div className="bg-gray-800 p-4 rounded-lg">
        <h3 className="text-lg font-medium text-white mb-4">
          Total Services Provided
        </h3>
        <ResponsiveContainer width="100%" height={300}>
          <BarChart data={serviceData}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="name" stroke="#fff" />
            <YAxis stroke="#fff" />
            <Tooltip />
            <Legend />
            <Bar dataKey="value" fill="#8884d8" />
          </BarChart>
        </ResponsiveContainer>
      </div>

      {/* Payment Types */}
      <div className="bg-gray-800 p-4 rounded-lg">
        <h3 className="text-lg font-medium text-white mb-4">
          Payment Types Breakdown
        </h3>
        <ResponsiveContainer width="100%" height={300}>
          <PieChart>
            <Pie
              data={paymentData}
              cx="50%"
              cy="50%"
              labelLine={false}
              outerRadius={100}
              fill="#8884d8"
              dataKey="value"
            >
              {paymentData.map((entry, index) => (
                <Cell
                  key={`cell-${index}`}
                  fill={COLORS[index % COLORS.length]}
                />
              ))}
            </Pie>
            <Tooltip />
            <Legend />
          </PieChart>
        </ResponsiveContainer>
      </div>

      {/* Monthly Revenue */}
      <div className="bg-gray-800 p-4 rounded-lg">
        <h3 className="text-lg font-medium text-white mb-4">
          Monthly Revenue Trend
        </h3>
        <ResponsiveContainer width="100%" height={300}>
          <LineChart data={revenueData}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="month" stroke="#fff" />
            <YAxis stroke="#fff" />
            <Tooltip />
            <Legend />
            <Line
              type="monotone"
              dataKey="revenue"
              stroke="#8884d8"
              activeDot={{ r: 8 }}
            />
          </LineChart>
        </ResponsiveContainer>
      </div>

      {/* Pending Payments */}
      <div className="bg-gray-800 p-4 rounded-lg">
        <h3 className="text-lg font-medium text-white mb-4">
          Pending Payments
        </h3>
        <ResponsiveContainer width="100%" height={300}>
          <BarChart data={pendingPayments}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="name" stroke="#fff" />
            <YAxis stroke="#fff" />
            <Tooltip />
            <Legend />
            <Bar dataKey="amount" fill="#ff4d4d" />
          </BarChart>
        </ResponsiveContainer>
      </div>

      {/* Top Services */}
      <div className="bg-gray-800 p-4 rounded-lg">
        <h3 className="text-lg font-medium text-white mb-4">
          Top Services Availed
        </h3>
        <ResponsiveContainer width="100%" height={300}>
          <BarChart data={topServices}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="name" stroke="#fff" />
            <YAxis stroke="#fff" />
            <Tooltip />
            <Legend />
            <Bar dataKey="count" fill="#82ca9d" />
          </BarChart>
        </ResponsiveContainer>
      </div>

      {/* Expenditure vs Revenue */}
      <div className="bg-gray-800 p-4 rounded-lg">
        <h3 className="text-lg font-medium text-white mb-4">
          Expenditure vs Revenue
        </h3>
        <ResponsiveContainer width="100%" height={300}>
          <LineChart data={expenditureVsRevenue}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="month" stroke="#fff" />
            <YAxis stroke="#fff" />
            <Tooltip />
            <Legend />
            <Line
              type="monotone"
              dataKey="revenue"
              stroke="#82ca9d"
              activeDot={{ r: 8 }}
            />
            <Line
              type="monotone"
              dataKey="expenditure"
              stroke="#ff4d4d"
              activeDot={{ r: 8 }}
            />
          </LineChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}