import React, { useState, useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { Upload, X } from 'lucide-react';
import { storage, db } from '../firebase';
import { ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import { collection, addDoc, serverTimestamp } from 'firebase/firestore';
import { useAuth } from '../hooks/useAuth';
import toast from 'react-hot-toast';
import { v4 as uuidv4 } from 'uuid';

export default function CustomerForm() {
  const { register, handleSubmit, reset, formState: { errors } } = useForm();
  const [files, setFiles] = useState([]);
  const { user } = useAuth();
  
  const generateCustomerId = (name, mobile) => {
    const nameInitials = name.split(' ').map(n => n[0]).join('').toUpperCase();
    const mobileEnd = mobile.slice(-4);
    const randomStr = Math.random().toString(36).substring(2, 4).toUpperCase();
    return `${nameInitials}${mobileEnd}${randomStr}`;
  };

  const onSubmit = async (data) => {
    try {
      const customerId = generateCustomerId(data.name, data.mobile);
      const documents = await Promise.all(
        files.map(async (file) => {
          const storageRef = ref(storage, `documents/${customerId}/${file.name}`);
          await uploadBytes(storageRef, file);
          const url = await getDownloadURL(storageRef);
          return {
            name: file.name,
            url,
            uploadedAt: new Date()
          };
        })
      );

      await addDoc(collection(db, 'customers'), {
        ...data,
        customerId,
        documents,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
        editCount: 0,
        createdBy: user.uid,
        lastEditedBy: user.uid
      });

      toast.success('Customer added successfully');
      reset();
      setFiles([]);
    } catch (error) {
      toast.error('Error adding customer');
      console.error(error);
    }
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <label className="block text-sm font-medium text-gray-200">
            Customer Name
          </label>
          <input
            type="text"
            {...register('name', { required: true })}
            className="mt-1 block w-full rounded-md bg-gray-700 border-gray-600 text-white"
          />
          {errors.name && (
            <span className="text-red-500 text-sm">Name is required</span>
          )}
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-200">
            Mobile Number
          </label>
          <input
            type="tel"
            {...register('mobile', {
              required: true,
              pattern: /^[0-9]{10}$/
            })}
            className="mt-1 block w-full rounded-md bg-gray-700 border-gray-600 text-white"
          />
          {errors.mobile && (
            <span className="text-red-500 text-sm">
              Valid mobile number is required
            </span>
          )}
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-200">
            Service
          </label>
          <select
            {...register('service', { required: true })}
            className="mt-1 block w-full rounded-md bg-gray-700 border-gray-600 text-white"
          >
            <option value="">Select a service</option>
            <option value="aadhar">Aadhar Services</option>
            <option value="pan">PAN Card Services</option>
            <option value="voter">Voter ID Services</option>
            <option value="certificate">Certificate Services</option>
          </select>
          {errors.service && (
            <span className="text-red-500 text-sm">Service is required</span>
          )}
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-200">
            Payment Status
          </label>
          <select
            {...register('paymentStatus', { required: true })}
            className="mt-1 block w-full rounded-md bg-gray-700 border-gray-600 text-white"
          >
            <option value="">Select payment status</option>
            <option value="Cash">Cash</option>
            <option value="UPI">UPI</option>
            <option value="Cash+UPI">Cash+UPI</option>
            <option value="Pending">Pending</option>
          </select>
          {errors.paymentStatus && (
            <span className="text-red-500 text-sm">
              Payment status is required
            </span>
          )}
        </div>

        <div className="col-span-2">
          <label className="block text-sm font-medium text-gray-200">
            Documents
          </label>
          <div className="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-gray-600 border-dashed rounded-md">
            <div className="space-y-1 text-center">
              <Upload className="mx-auto h-12 w-12 text-gray-400" />
              <div className="flex text-sm text-gray-400">
                <label className="relative cursor-pointer rounded-md font-medium text-indigo-400 hover:text-indigo-300">
                  <span>Upload files</span>
                  <input
                    type="file"
                    multiple
                    className="sr-only"
                    onChange={(e) =>
                      setFiles([...files, ...Array.from(e.target.files)])
                    }
                  />
                </label>
              </div>
            </div>
          </div>
          <div className="mt-2 space-y-2">
            {files.map((file, index) => (
              <div
                key={index}
                className="flex items-center justify-between p-2 bg-gray-700 rounded"
              >
                <span className="text-sm text-gray-200">{file.name}</span>
                <button
                  type="button"
                  onClick={() =>
                    setFiles(files.filter((_, i) => i !== index))
                  }
                  className="text-red-400 hover:text-red-300"
                >
                  <X className="h-4 w-4" />
                </button>
              </div>
            ))}
          </div>
        </div>

        <div className="col-span-2">
          <label className="block text-sm font-medium text-gray-200">
            Notes
          </label>
          <textarea
            {...register('notes')}
            rows={4}
            className="mt-1 block w-full rounded-md bg-gray-700 border-gray-600 text-white"
          />
        </div>
      </div>

      <div className="flex justify-end">
        <button
          type="submit"
          className="px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-500"
        >
          Submit
        </button>
      </div>
    </form>
  );
}