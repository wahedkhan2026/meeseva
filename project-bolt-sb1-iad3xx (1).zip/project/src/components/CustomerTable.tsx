import React, { useState } from 'react';
import { useTable, useSortBy, useFilters, usePagination } from 'react-table';
import { Edit2, Trash2, Eye, FileText } from 'lucide-react';
import { format } from 'date-fns';

export default function CustomerTable({ data, onView, onEdit, onDelete, onPrint }) {
  const columns = React.useMemo(
    () => [
      {
        Header: 'Customer ID',
        accessor: 'customerId',
      },
      {
        Header: 'Name',
        accessor: 'name',
      },
      {
        Header: 'Mobile',
        accessor: 'mobile',
      },
      {
        Header: 'Service',
        accessor: 'service',
      },
      {
        Header: 'Payment Status',
        accessor: 'paymentStatus',
        Cell: ({ value }) => (
          <span
            className={`px-2 py-1 rounded-full text-xs ${
              value === 'Pending'
                ? 'bg-red-900 text-red-200'
                : 'bg-green-900 text-green-200'
            }`}
          >
            {value}
          </span>
        ),
      },
      {
        Header: 'Date',
        accessor: 'createdAt',
        Cell: ({ value }) => format(value.toDate(), 'dd/MM/yyyy HH:mm'),
      },
      {
        Header: 'Actions',
        Cell: ({ row }) => (
          <div className="flex space-x-2">
            <button
              onClick={() => onView(row.original)}
              className="text-blue-400 hover:text-blue-300"
            >
              <Eye className="h-5 w-5" />
            </button>
            <button
              onClick={() => onEdit(row.original)}
              className="text-yellow-400 hover:text-yellow-300"
            >
              <Edit2 className="h-5 w-5" />
            </button>
            <button
              onClick={() => onPrint(row.original)}
              className="text-green-400 hover:text-green-300"
            >
              <FileText className="h-5 w-5" />
            </button>
            <button
              onClick={() => onDelete(row.original)}
              className="text-red-400 hover:text-red-300"
            >
              <Trash2 className="h-5 w-5" />
            </button>
          </div>
        ),
      },
    ],
    [onView, onEdit, onDelete, onPrint]
  );

  const {
    getTableProps,
    getTableBodyProps,
    headerGroups,
    page,
    prepareRow,
    canPreviousPage,
    canNextPage,
    pageOptions,
    pageCount,
    gotoPage,
    nextPage,
    previousPage,
    setPageSize,
    state: { pageIndex, pageSize },
  } = useTable(
    {
      columns,
      data,
      initialState: { pageIndex: 0, pageSize: 10 },
    },
    useFilters,
    useSortBy,
    usePagination
  );

  return (
    <div className="space-y-4">
      <div className="overflow-x-auto">
        <table
          {...getTableProps()}
          className="min-w-full divide-y divide-gray-700"
        >
          <thead className="bg-gray-800">
            {headerGroups.map(headerGroup => (
              <tr {...headerGroup.getHeaderGroupProps()}>
                {headerGroup.headers.map(column => (
                  <th
                    {...column.getHeaderProps(column.getSortByToggleProps())}
                    className="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider"
                  >
                    {column.render('Header')}
                    <span>
                      {column.isSorted
                        ? column.isSortedDesc
                          ? ' ↓'
                          : ' ↑'
                        : ''}
                    </span>
                  </th>
                ))}
              </tr>
            ))}
          </thead>
          <tbody
            {...getTableBodyProps()}
            className="bg-gray-900 divide-y divide-gray-700"
          >
            {page.map(row => {
              prepareRow(row);
              return (
                <tr {...row.getRowProps()}>
                  {row.cells.map(cell => (
                    <td
                      {...cell.getCellProps()}
                      className="px-6 py-4 whitespace-nowrap text-sm text-gray-300"
                    >
                      {cell.render('Cell')}
                    </td>
                  ))}
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      <div className="flex items-center justify-between">
        <div className="flex gap-x-2">
          <button
            onClick={() => gotoPage(0)}
            disabled={!canPreviousPage}
            className="px-2 py-1 border border-gray-700 rounded-md disabled:opacity-50"
          >
            {'<<'}
          </button>
          <button
            onClick={() => previousPage()}
            disabled={!canPreviousPage}
            className="px-2 py-1 border border-gray-700 rounded-md disabled:opacity-50"
          >
            {'<'}
          </button>
          <button
            onClick={() => nextPage()}
            disabled={!canNextPage}
            className="px-2 py-1 border border-gray-700 rounded-md disabled:opacity-50"
          >
            {'>'}
          </button>
          <button
            onClick={() => gotoPage(pageCount - 1)}
            disabled={!canNextPage}
            className="px-2 py-1 border border-gray-700 rounded-md disabled:opacity-50"
          >
            {'>>'}
          </button>
        </div>
        <span className="text-sm text-gray-400">
          Page{' '}
          <strong>
            {pageIndex + 1} of {pageOptions.length}
          </strong>
        </span>
        <select
          value={pageSize}
          onChange={e => {
            setPageSize(Number(e.target.value));
          }}
          className="bg-gray-700 border border-gray-600 text-gray-300 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block p-2.5"
        >
          {[10, 20, 30, 40, 50].map(pageSize => (
            <option key={pageSize} value={pageSize}>
              Show {pageSize}
            </option>
          ))}
        </select>
      </div>
    </div>
  );
}