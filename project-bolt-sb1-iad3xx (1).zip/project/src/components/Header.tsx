import React from 'react';
import { useAuth } from '../hooks/useAuth';
import { Bell, LogOut, User } from 'lucide-react';

export default function Header() {
  const { user, signOut } = useAuth();

  return (
    <header className="bg-gray-800 border-b border-gray-700">
      <div className="container mx-auto px-6 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <h1 className="text-2xl font-semibold text-white">
              Meeseva Telangana
            </h1>
          </div>
          
          <div className="flex items-center space-x-4">
            <button className="text-gray-300 hover:text-white">
              <Bell className="h-6 w-6" />
            </button>
            
            <div className="relative">
              <button className="flex items-center space-x-2 text-gray-300 hover:text-white">
                <User className="h-6 w-6" />
                <span>{user?.name}</span>
              </button>
            </div>
            
            <button 
              onClick={signOut}
              className="flex items-center space-x-2 text-gray-300 hover:text-white"
            >
              <LogOut className="h-6 w-6" />
            </button>
          </div>
        </div>
      </div>
    </header>
  );
}