import React from 'react';
import { NavLink } from 'react-router-dom';
import { 
  Home, 
  Users, 
  FileText, 
  BarChart2, 
  Settings,
  Receipt,
  Calendar,
  DollarSign
} from 'lucide-react';
import { useAuth } from '../hooks/useAuth';

export default function Sidebar() {
  const { user } = useAuth();
  
  const navigation = [
    { name: 'Dashboard', icon: Home, href: '/' },
    { name: 'Customers', icon: Users, href: '/customers' },
    { name: 'Services', icon: FileText, href: '/services' },
    { name: 'Reports', icon: BarChart2, href: '/reports' },
    { name: 'Daily Summary', icon: Calendar, href: '/daily-summary' },
    { name: 'Expenses', icon: DollarSign, href: '/expenses' },
    { name: 'Invoices', icon: Receipt, href: '/invoices' },
    ...(user?.role === 'admin' ? [
      { name: 'Settings', icon: Settings, href: '/settings' }
    ] : [])
  ];

  return (
    <div className="flex flex-col w-64 bg-gray-800">
      <div className="flex items-center justify-center h-16 bg-gray-900">
        <span className="text-white font-bold text-xl">MeeSeva Portal</span>
      </div>
      
      <div className="flex flex-col flex-1 overflow-y-auto">
        <nav className="flex-1 px-2 py-4 space-y-2">
          {navigation.map((item) => (
            <NavLink
              key={item.name}
              to={item.href}
              className={({ isActive }) =>
                `flex items-center px-4 py-2 text-sm font-medium rounded-lg ${
                  isActive
                    ? 'bg-gray-900 text-white'
                    : 'text-gray-300 hover:bg-gray-700 hover:text-white'
                }`
              }
            >
              <item.icon className="h-5 w-5 mr-3" />
              {item.name}
            </NavLink>
          ))}
        </nav>
      </div>
    </div>
  );
}