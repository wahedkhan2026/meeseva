import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';
import { getStorage } from 'firebase/storage';

const firebaseConfig = {
  apiKey: "AIzaSyBk_7Z64f6X1d8okwyyHT4P9bRkqOfVf7w",
  authDomain: "digihub-portal-731cb.firebaseapp.com",
  projectId: "digihub-portal-731cb",
  storageBucket: "digihub-portal-731cb.appspot.com", // corrected `.app` to `.com`
  messagingSenderId: "553899762508",
  appId: "1:553899762508:web:4f9462f87dc7f952f025e9",
  measurementId: "G-SWZ4J51S3J"
};

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);
export const storage = getStorage(app);
