import React, { useState, useEffect } from 'react';
import CustomerForm from '../components/CustomerForm';
import CustomerTable from '../components/CustomerTable';
import { collection, query, orderBy, onSnapshot, doc, deleteDoc } from 'firebase/firestore';
import { db } from '../firebase';
import toast from 'react-hot-toast';
import { jsPDF } from 'jspdf';

export default function Customers() {
  const [customers, setCustomers] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [selectedCustomer, setSelectedCustomer] = useState(null);

  useEffect(() => {
    const q = query(collection(db, 'customers'), orderBy('createdAt', 'desc'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      setCustomers(
        snapshot.docs.map((doc) => ({
          id: doc.id,
          ...doc.data()
        }))
      );
    });

    return () => unsubscribe();
  }, []);

  const handleView = (customer) => {
    setSelectedCustomer(customer);
    // Implement view modal
  };

  const handleEdit = (customer) => {
    setSelectedCustomer(customer);
    setShowForm(true);
  };

  const handleDelete = async (customer) => {
    if (window.confirm('Are you sure you want to delete this customer?')) {
      try {
        await deleteDoc(doc(db, 'customers', customer.id));
        toast.success('Customer deleted successfully');
      } catch (error) {
        toast.error('Error deleting customer');
        console.error(error);
      }
    }
  };

  const handlePrint = (customer) => {
    const doc = new jsPDF();
    
    // Add content to PDF
    doc.setFontSize(20);
    doc.text('Customer Details', 20, 20);
    
    doc.setFontSize(12);
    doc.text(`Customer ID: ${customer.customerId}`, 20, 40);
    doc.text(`Name: ${customer.name}`, 20, 50);
    doc.text(`Mobile: ${customer.mobile}`, 20, 60);
    doc.text(`Service: ${customer.service}`, 20, 70);
    doc.text(`Payment Status: ${customer.paymentStatus}`, 20, 80);
    doc.text(`Notes: ${customer.notes || 'N/A'}`, 20, 90);
    
    // Save the PDF
    doc.save(`customer-${customer.customerId}.pdf`);
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-white">Customers</h2>
        <button
          onClick={() => {
            setSelectedCustomer(null);
            setShowForm(!showForm);
          }}
          className="px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-500"
        >
          {showForm ? 'View Customers' : 'Add Customer'}
        </button>
      </div>

      {showForm ? (
        <CustomerForm
          customer={selectedCustomer}
          onSuccess={() => {
            setShowForm(false);
            setSelectedCustomer(null);
          }}
        />
      ) : (
        <CustomerTable
          data={customers}
          onView={handleView}
          onEdit={handleEdit}
          onDelete={handleDelete}
          onPrint={handlePrint}
        />
      )}
    </div>
  );
}