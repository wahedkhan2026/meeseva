import React, { useEffect, useState } from 'react';
import Analytics from '../components/Analytics';
import { collection, query, where, getDocs } from 'firebase/firestore';
import { db } from '../firebase';
import { format, startOfDay, endOfDay } from 'date-fns';

export default function Dashboard() {
  const [analyticsData, setAnalyticsData] = useState({
    serviceData: [],
    paymentData: [],
    revenueData: [],
    pendingPayments: [],
    topServices: [],
    expenditureVsRevenue: []
  });

  useEffect(() => {
    const fetchData = async () => {
      const today = new Date();
      const todayStart = startOfDay(today);
      const todayEnd = endOfDay(today);

      // Fetch today's transactions
      const transactionsRef = collection(db, 'customers');
      const todayQuery = query(
        transactionsRef,
        where('createdAt', '>=', todayStart),
        where('createdAt', '<=', todayEnd)
      );

      const snapshot = await getDocs(todayQuery);
      const transactions = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      }));

      // Process data for analytics
      const serviceCount = {};
      const paymentTypes = { Cash: 0, UPI: 0, 'Cash+UPI': 0, Pending: 0 };
      let totalRevenue = 0;

      transactions.forEach(transaction => {
        // Count services
        serviceCount[transaction.service] = (serviceCount[transaction.service] || 0) + 1;
        
        // Count payment types
        paymentTypes[transaction.paymentStatus]++;
        
        // Calculate revenue
        if (transaction.paymentAmount) {
          totalRevenue += transaction.paymentAmount;
        }
      });

      setAnalyticsData({
        serviceData: Object.entries(serviceCount).map(([name, value]) => ({
          name,
          value
        })),
        paymentData: Object.entries(paymentTypes).map(([name, value]) => ({
          name,
          value
        })),
        revenueData: [
          { month: format(today, 'MMM'), revenue: totalRevenue }
        ],
        pendingPayments: transactions
          .filter(t => t.paymentStatus === 'Pending')
          .map(t => ({
            name: t.customerId,
            amount: t.paymentAmount
          })),
        topServices: Object.entries(serviceCount)
          .sort(([, a], [, b]) => b - a)
          .slice(0, 5)
          .map(([name, count]) => ({ name, count })),
        expenditureVsRevenue: [
          {
            month: format(today, 'MMM'),
            revenue: totalRevenue,
            expenditure: 0 // This should be fetched from expenses collection
          }
        ]
      });
    };

    fetchData();
    const interval = setInterval(fetchData, 300000); // Refresh every 5 minutes

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-white">Dashboard</h2>
      <Analytics data={analyticsData} />
    </div>
  );
}