export interface Customer {
  id: string;
  customerId: string;
  name: string;
  mobile: string;
  service: string;
  documents: DocumentInfo[];
  paymentStatus: 'Cash' | 'UPI' | 'Cash+UPI' | 'Pending';
  paymentAmount: number;
  notes: string;
  createdAt: Date;
  updatedAt: Date;
  editCount: number;
  createdBy: string;
  lastEditedBy: string;
}

export interface DocumentInfo {
  name: string;
  url: string;
  uploadedAt: Date;
}

export interface User {
  uid: string;
  email: string;
  role: 'admin' | 'employee';
  name: string;
}

export interface Service {
  id: string;
  name: string;
  description: string;
  price: number;
}

export interface Expense {
  id: string;
  category: string;
  amount: number;
  date: Date;
  description: string;
  createdBy: string;
}